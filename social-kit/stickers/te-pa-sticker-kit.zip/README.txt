Te Pā Tūwatawata — Street Activist Sticker Kit
================================================
Created by www.kiwidialectic.com

12 stickers + 1 A4 printable sheet (300dpi, print-ready)

Formats:
  sticker-s01 to s04 — Rectangle 90×50mm  (bump/laptop stickers)
  sticker-s05 to s08 — Square   85×85mm   (pole/wall stickers)
  sticker-s09 to s12 — Circle   80mm diam (helmet/bin stickers)
  sticker-sheet-a4   — All 12 on A4 @ 300dpi

Slogans drawn from real Māori protest tradition:
  Ihumātao · Hīkoi mō Te Tiriti · Wai 262 · Data sovereignty

Inspired by: Tāme Iti propaganda poster tradition,
Colin McCahon word-as-image painting, Kaupapa Māori art pedagogy.

Free to print and distribute for non-commercial activist use
under CC BY-NC-SA 4.0.
Attribution: The Kiwi Dialectic — kiwidialectic.com
